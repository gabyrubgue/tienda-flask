// Main client-side JS. Handles UI behavior, localStorage persistence, and mock auth.
// AQUI PEGAR FIREBASE CONFIG si deseas usar Firebase Auth (ver README).
// KEY POINTS: products stored in localStorage under 'tienda_products_v1'
// cart stored under 'tienda_cart_v1'
(function(){
      const addBtn = card.querySelector('.add-btn')
      addBtn.addEventListener('click', ()=>{
        if(p.allowQty){
          const qty = prompt('Cantidad (1-99)', '1')
          const q = Math.max(1, Math.min(99, Number(qty)||1))
          addToCart({...p, quantity: q})
        } else {
          addToCart({...p, quantity: 1})
        }
      })
      productGrid.appendChild(card)
    })
    updateCartBadge()
  }

  function addToCart(item){
    const exists = cart.find(i=>i.id===item.id)
    if(exists){
      exists.quantity = (exists.quantity || 0) + (item.quantity || 1)
    } else {
      cart.push({...item})
    }
    saveCart(cart)
    updateCartBadge()
    alert('Producto añadido al carrito')
  }

  function updateCartBadge(){
    const count = cart.reduce((s,i)=>s + (i.quantity||0), 0)
    if(count>0){ cartBadge.textContent = count; cartBadge.classList.remove('hidden') } else { cartBadge.classList.add('hidden') }
  }

  function renderCart(){
    cartList.innerHTML = ''
    let total = 0
    cart.forEach(item=>{
      const row = document.createElement('div'); row.className='flex items-center justify-between border p-2 rounded'
      row.innerHTML = `<div><div class="font-semibold">${item.name}</div><div class="text-sm">$${item.price.toLocaleString()}</div></div>
      <div class="flex items-center gap-2">
        <input type="number" min="1" max="99" value="${item.quantity||1}" class="w-20 p-1 border rounded qty-input" />
        <div class="w-28">Subtotal: $${(item.price * (item.quantity||1)).toLocaleString()}</div>
        <button class="remove-btn px-2 py-1 bg-red-500 text-white rounded">Eliminar</button>
      </div>`
      row.querySelector('.remove-btn').addEventListener('click', ()=>{ cart = cart.filter(c=>c.id!==item.id); saveCart(cart); renderCart(); updateCartBadge(); })
      row.querySelector('.qty-input').addEventListener('change', (e)=>{ item.quantity = Math.max(1,Math.min(99,Number(e.target.value)||1)); saveCart(cart); renderCart(); updateCartBadge(); })
      cartList.appendChild(row)
      total += item.price * (item.quantity||1)
    })
    cartTotal.textContent = '$' + total.toLocaleString()
  }

  // Form handlers
  pImage.addEventListener('change', (e)=>{
    const f = e.target.files[0]; if(!f) return
    const r = new FileReader(); r.onload = ()=>{ pPreview.src = r.result; pPreview.classList.remove('hidden') }; r.readAsDataURL(f)
  })

  addForm.addEventListener('submit', (e)=>{
    e.preventDefault()
    const name = pName.value.trim(); const price = Number(pPrice.value)
    if(!name){ alert('Nombre requerido'); return }
    if(!price || price<=0){ alert('Precio debe ser mayor a 0'); return }
    const id = 'p_' + Date.now()
    const image = pPreview.src || ''
    const newItem = { id, name, price, image, allowQty: pAllowQty.checked }
    products.unshift(newItem)
    saveProducts(products)
    pName.value=''; pPrice.value=''; pAllowQty.checked=false; pPreview.src=''; pPreview.classList.add('hidden'); pImage.value=''
    renderProducts()
  })

  exportBtn.addEventListener('click', ()=>{
    const data = JSON.stringify(products, null, 2)
    const blob = new Blob([data], {type:'application/json'}); const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href=url; a.download='products.json'; a.click()
  })
  importBtn.addEventListener('click', ()=>{
    try {
      const parsed = JSON.parse(importArea.value)
      products = parsed; saveProducts(products); renderProducts(); alert('Importado OK')
    } catch(e){ alert('JSON inválido') }
  })

  // Cart modal handlers
  cartBtn.addEventListener('click', ()=>{ cartModal.classList.remove('hidden'); cartModal.classList.add('flex'); renderCart() })
  document.getElementById('mobile-cart').addEventListener('click', ()=>{ cartModal.classList.remove('hidden'); cartModal.classList.add('flex'); renderCart() })
  closeCartBtn.addEventListener('click', ()=>{ cartModal.classList.add('hidden'); cartModal.classList.remove('flex') })
  clearCartBtn.addEventListener('click', ()=>{ cart = []; saveCart(cart); renderCart(); updateCartBadge() })
  checkoutBtn.addEventListener('click', ()=>{ console.log('Checkout simulado', cart); alert('Checkout simulado - revisar consola'); cart=[]; saveCart(cart); renderCart(); updateCartBadge() })

  // ESC closes modals
  window.addEventListener('keydown', (e)=>{ if(e.key==='Escape'){ if(!cartModal.classList.contains('hidden')){ cartModal.classList.add('hidden'); cartModal.classList.remove('flex') } } })

  // Site name and logo inline edit
  siteNameInput.addEventListener('input', ()=>{ config.name = siteNameInput.value; saveConfig(config) })
  adminToggle.addEventListener('click', ()=>{ adminPanel.classList.toggle('hidden') })
  adminName.addEventListener('input', ()=>{ siteNameInput.value = adminName.value; config.name = adminName.value; saveConfig(config) })

  adminLogo.addEventListener('change', (e)=>{ const f = e.target.files[0]; if(!f) return; const r = new FileReader(); r.onload = ()=>{ siteLogoImg.src = r.result; siteLogoImg.classList.remove('hidden'); config.logo = r.result; saveConfig(config) }; r.readAsDataURL(f) })

  exportConfigBtn.addEventListener('click', ()=>{
    const data = JSON.stringify({ config, products }, null, 2); const blob = new Blob([data], {type:'application/json'}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url; a.download='tienda-config.json'; a.click()
  })
  importConfigBtn.addEventListener('click', ()=>{
    try {
      const parsed = JSON.parse(importConfigText.value)
      if(parsed.config){ config = parsed.config; saveConfig(config); if(config.name) siteNameInput.value=config.name; if(config.logo){ siteLogoImg.src=config.logo; siteLogoImg.classList.remove('hidden') } }
      if(parsed.products){ products = parsed.products; saveProducts(products); renderProducts() }
      alert('Importado OK')
    } catch(e){ alert('JSON inválido') }
  })

  // Services save
  saveServicesBtn.addEventListener('click', ()=>{ config.services = servicesText.value; saveConfig(config); alert('Servicios guardados') })

  // Contact form
  contactForm.addEventListener('submit', (e)=>{
    e.preventDefault()
    const name = document.getElementById('contact-name').value
    const email = document.getElementById('contact-email').value
    const msg = document.getElementById('contact-msg').value
    if(!name||!email||!msg){ alert('Completa los campos'); return }
    console.log('Contacto enviado (simulado):', {name,email,msg})
    alert('Mensaje enviado (simulado). Revisar consola.')
    contactForm.reset()
  })

  // Footer inputs save on change
  document.getElementById('footer-address').addEventListener('input', (e)=>{ config.address = e.target.value; saveConfig(config) })
  document.getElementById('footer-phone').addEventListener('input', (e)=>{ config.phone = e.target.value; saveConfig(config) })
  document.getElementById('footer-hours').addEventListener('input', (e)=>{ config.hours = e.target.value; saveConfig(config) })
  document.getElementById('footer-social').addEventListener('input', (e)=>{ config.social = e.target.value; saveConfig(config) })

  // Mobile menu
  document.getElementById('hamburger').addEventListener('click', ()=>{ document.getElementById('mobile-menu').classList.toggle('hidden') })

  // Initial render
  renderProducts()
  updateCartBadge()
})();
